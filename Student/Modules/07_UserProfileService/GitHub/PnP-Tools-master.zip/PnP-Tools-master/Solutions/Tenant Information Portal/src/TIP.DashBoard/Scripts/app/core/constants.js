﻿
(function () {
    'use strict';

    angular
        .module('app.core')
        .constant('toastr', toastr);
})();