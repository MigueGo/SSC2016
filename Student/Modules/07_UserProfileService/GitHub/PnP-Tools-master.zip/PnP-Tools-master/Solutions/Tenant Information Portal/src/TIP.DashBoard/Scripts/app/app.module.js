﻿(function () {
    'use strict';

    angular.module('app', [
        /*
        * Features
        */
        'app.core', 'app.dashboard', 'app.principal' , 'app.reports'
    ]);
})();